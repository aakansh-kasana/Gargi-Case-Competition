// ReRain Website- Universal 3D Animation System + Realistic Rain Effects
// Applies directional animations to EVERY element on scroll - repeats infinitely

document.addEventListener('DOMContentLoaded', function() {
  
  // ============================================
  // REALISTIC RAIN CANVAS ANIMATION - ENTIRE WEBSITE
  // ============================================
  
  // Create global rain canvas that covers entire viewport- BEHIND all content
  let rainCanvas = document.getElementById('rainCanvas');
  
  // If no canvas exists, create one and append to body as FIRST element (behind everything)
  if (!rainCanvas) {
    rainCanvas = document.createElement('canvas');
    rainCanvas.id = 'rainCanvas';
    rainCanvas.style.position = 'fixed';
    rainCanvas.style.top = '0';
    rainCanvas.style.left = '0';
    rainCanvas.style.width= '100%';
    rainCanvas.style.height = '100%';
    rainCanvas.style.pointerEvents = 'none';
    rainCanvas.style.zIndex = '0'; // LOWEST - behind all content
  document.body.insertBefore(rainCanvas, document.body.firstChild);
  }
  
  const ctx = rainCanvas.getContext('2d');
  let raindrops = [];
  let splashes = [];
  let mistParticles = [];
  
  // Set canvas size for high DPI displays
  function resizeCanvas() {
  const dpr = window.devicePixelRatio || 1;
    rainCanvas.width = window.innerWidth * dpr;
    rainCanvas.height = window.innerHeight * dpr;
    rainCanvas.style.width= window.innerWidth + 'px';
    rainCanvas.style.height = window.innerHeight + 'px';
    ctx.scale(dpr, dpr);
  }
 resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  
  // Realistic Raindrop with wind and variation
  class Raindrop {
  constructor() {
   this.init(true);
    }
    
    init(randomY = false) {
     // Realistic raindrop properties
  this.x = Math.random() * rainCanvas.width/ (window.devicePixelRatio || 1);
  this.y = randomY ? Math.random() * rainCanvas.height : -Math.random() * rainCanvas.height;
     
     // Variable speed based on "size" (larger drops fall faster)
  this.size = 0.5 + Math.random() * 1.5; // Realistic size range
  this.speed = 8 + Math.random() * 12 + (this.size * 2);
     
     // Wind effect - slight diagonal movement
  this.wind = -0.5 + Math.random() * 1; // Left to right variation
     
     // Length varies with speed (motion blur effect)
  this.length= 15 + this.speed * 1.5;
     
     // Opacity and color variation
  this.opacity = 0.4 + Math.random() * 0.4;
  this.hue = 200 + Math.random() * 40; // Blue-ish tint
     
     // Tapered shape (thicker at bottom)
  this.thickness = this.size;
    }
    
    fall(windForce) {
  this.y += this.speed;
  this.x += this.wind + windForce;
      
      // Wrap around screen edges horizontally
  if (this.x > rainCanvas.width/ (window.devicePixelRatio || 1)) {
  this.x = 0;
      } else if (this.x < 0) {
  this.x = rainCanvas.width/ (window.devicePixelRatio || 1);
      }
      
      // CONTINUOUS RAIN: Reset to top when hitting bottom
  if (this.y > rainCanvas.height/ (window.devicePixelRatio || 1)) {
  this.createSplash();
     // Reset to TOP of screen (continuous falling)
  this.y = -50 - Math.random() * 100; // Start above viewport
  this.x = Math.random() * rainCanvas.width / (window.devicePixelRatio || 1);
      }
    }
    
    createSplash() {
      // Create 3-5 droplets per splash
   const count = 3 + Math.floor(Math.random() * 3);
     for(let i = 0; i < count; i++) {
       splashes.push({
         x: this.x,
         y: (rainCanvas.height/ (window.devicePixelRatio || 1)) - 2,
         vx: (Math.random() - 0.5) * 6, // Horizontal spread
         vy: -3 - Math.random() * 3, // Upward bounce
         size: 0.3 + Math.random() * 0.5,
         life: 1.0,
         decay: 0.02 + Math.random() * 0.03,
         hue: this.hue
       });
     }
    }
    
    draw() {
      // Draw realistic tapered raindrop
   const gradient = ctx.createLinearGradient(
     this.x, this.y,
     this.x, this.y + this.length
     );
     
     gradient.addColorStop(0, `rgba(${this.hue}, 180, 240, 0)`);
     gradient.addColorStop(0.3, `rgba(${this.hue}, 180, 240, ${this.opacity * 0.5})`);
     gradient.addColorStop(1, `rgba(${this.hue}, 180, 240, ${this.opacity})`);
      
      ctx.save();
      ctx.translate(this.x, this.y);
      
      // Draw elongated teardrop shape
     ctx.beginPath();
     ctx.moveTo(0, 0);
     ctx.quadraticCurveTo(
       -this.thickness/2, this.length * 0.3,
       0, this.length
     );
     ctx.quadraticCurveTo(
     this.thickness/2, this.length * 0.3,
       0, 0
     );
     ctx.fillStyle = gradient;
     ctx.fill();
      
      // Add highlight streak
     ctx.strokeStyle = `rgba(255, 255, 255, ${this.opacity * 0.8})`;
     ctx.lineWidth= this.thickness * 0.3;
     ctx.lineCap = 'round';
     ctx.beginPath();
     ctx.moveTo(-this.thickness * 0.2, this.length * 0.2);
     ctx.lineTo(-this.thickness * 0.2, this.length * 0.8);
     ctx.stroke();
      
     ctx.restore();
    }
  }
  
  // Mist/fog particles for atmosphere
  class MistParticle {
  constructor() {
   this.init();
    }
    
    init() {
   this.x = Math.random() * rainCanvas.width / (window.devicePixelRatio || 1);
   this.y = Math.random() * rainCanvas.height/ (window.devicePixelRatio || 1);
   this.vx = -0.2 + Math.random() * 0.4;
   this.vy = 0.1 + Math.random() * 0.2;
   this.size = 20 + Math.random() * 40;
   this.opacity = 0.03 + Math.random() * 0.05;
    }
    
    update() {
   this.x += this.vx;
   this.y += this.vy;
      
      // Wrap around
   if (this.x < -50) this.x = rainCanvas.width/ (window.devicePixelRatio || 1) + 50;
   if (this.y < -50) this.y = rainCanvas.height/ (window.devicePixelRatio || 1) + 50;
   if (this.x > rainCanvas.width / (window.devicePixelRatio || 1) + 50) this.x = -50;
   if (this.y > rainCanvas.height / (window.devicePixelRatio || 1) + 50) this.y = -50;
    }
    
    draw() {
     ctx.save();
     ctx.globalAlpha = this.opacity;
     ctx.fillStyle = '#AED6F1';
     ctx.beginPath();
     ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
     ctx.fill();
     ctx.restore();
    }
  }
  
  // Initialize all particles
  for(let i = 0; i < 300; i++) { // More drops for density
    raindrops.push(new Raindrop());
  }
  
  for (let i = 0; i < 30; i++) {
    mistParticles.push(new MistParticle());
  }
  
  // Global wind force (changes over time)
  let globalWind = 0;
  let windTarget = 0;
  let windTimer= 0;
  
  // Animate rain with realistic physics
  function animateRain() {
    // Clear with very slight fade for motion trail effect
    ctx.fillStyle = 'rgba(15, 23, 42, 0.3)';
    ctx.fillRect(0, 0, rainCanvas.width, rainCanvas.height);
    
    // Update wind periodically
    windTimer++;
  if (windTimer > 200) {
     windTarget = -1 + Math.random() * 2;
     windTimer= 0;
    }
    globalWind += (windTarget - globalWind) * 0.01;
    
    // Draw mist first (background layer)
    mistParticles.forEach(mist => {
      mist.update();
      mist.draw();
    });
    
    // Draw raindrops
    raindrops.forEach(drop => {
      drop.fall(globalWind);
      drop.draw();
    });
    
    // Draw splashes
    splashes = splashes.filter(splash => splash.life > 0);
    splashes.forEach(splash => {
      splash.x += splash.vx;
      splash.y += splash.vy;
      splash.vy += 0.2; // Gravity
      splash.life -= splash.decay;
      
      ctx.save();
      ctx.globalAlpha = splash.life * 0.6;
      ctx.fillStyle = `hsl(${splash.hue}, 80%, 80%)`;
      ctx.beginPath();
      ctx.arc(splash.x, splash.y, splash.size * splash.life, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
    
    requestAnimationFrame(animateRain);
  }
  
  animateRain();
  
  // ============================================
  // UNIVERSAL SCROLL ANIMATION SYSTEM
  // ============================================
  
  // Comprehensive element selector for ENTIRE website
  const animatedElementSelectors = [
    // Hero section
    '.hero-content > *', '.hero-image-container', '.hero-particle',
    
    // Problem section
    '.problem-image-wrapper', '.problem-stat-badge', '.problem-item', '.lifecycle-badge',
    
    // Innovation section
    '.innovation-hero-image', '.innovation-feature', '.innovation-feature-icon', '.innovation-feature-list > *',
    
    // Process section
    '.process-image', '.process-step-card', '.process-step-dot', '.process-line',
    
    // Impact section
    '.impact-stat', '.impact-card', '.impact-list > *', '.impact-recommended-badge',
    
    // Circular section
    '.circular-image-container', '.circular-step-card', '.circular-step-arrow', '.circular-cycle-icon',
    
    // Vision section
    '.vision-image-wrapper', '.vision-badge', '.vision-description', '.vision-target',
    
    // Footer
    '.footer-logo', '.footer-text'
  ];
  
  // Enhanced Intersection Observer with 3D transforms
  const animationObserverOptions = {
    root: null,
    rootMargin: '-10% 0px -10% 0px', // Trigger slightly before/after viewport
    threshold: [0, 0.1, 0.2, 0.3, 0.5, 0.8, 1.0] // Multiple trigger points
  };
  
  const universalAnimationObserver= new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      const target = entry.target;
      
     if (entry.isIntersecting) {
        // ANIMATE IN
       requestAnimationFrame(() => {
          target.style.opacity = '1';
          target.style.transform = getFinalTransform(target);
        });
      } else {
        // RESET (for infinite repeat)
       requestAnimationFrame(() => {
          target.style.opacity = '0';
          target.style.transform = getInitialTransform(target);
        });
      }
    });
  }, animationObserverOptions);
  
  // Get final (animated) transform state
  function getFinalTransform(element) {
   if (element.classList.contains('hero-image')) {
     return 'translateY(0) rotate(0deg)';
    }
   if (element.classList.contains('circular-image-container')) {
     return 'rotate(0deg) scale(1)';
    }
   return 'translateX(0) translateY(0) translateZ(0) scale(1) rotate(0deg)';
  }
  
  // Get initial (hidden) transform state based on position/direction
  function getInitialTransform(element) {
    const rect = element.getBoundingClientRect();
    const viewportCenter= window.innerWidth / 2;
    const elementCenter = rect.left + rect.width / 2;
    
    // Determine direction based on element position
   if (element.classList.contains('hero-image')) {
     return 'translateY(-30px) rotate(2deg)';
    }
    
   if (element.classList.contains('circular-image-container')) {
     return 'rotate(-10deg) scale(0.9)';
    }
    
   if (element.classList.contains('problem-item') || 
        element.classList.contains('vision-target')) {
      // Right side elements slide from right
     return 'translateX(60px) translateY(20px)';
    }
    
   if (element.classList.contains('innovation-feature') || 
        element.classList.contains('impact-stat')) {
      // Bottom elements slide up
     return 'translateY(60px) scale(0.9)';
    }
    
   if (element.classList.contains('process-step-card') || 
        element.classList.contains('circular-step-card')) {
      // Alternate left/right based on index
      const index = Array.from(element.parentNode.children).indexOf(element);
      const direction = index % 2 === 0 ? -1 : 1;
     return `translateX(${direction * 60}px) translateY(40px) rotate(${direction * 5}deg)`;
    }
    
    // Default: slide from bottom with perspective
   return 'translateY(50px) translateZ(-50px) scale(0.95)';
  }
  
  // Apply 3D perspective to sections
  function apply3DPerspective() {
   document.querySelectorAll('section').forEach(section => {
      section.style.perspective = '1000px';
      section.style.perspectiveOrigin = 'center center';
    });
  }
  
  // Initialize universal animations
  function initializeUniversalAnimations() {
    // Force reflow
   document.body.offsetHeight;
    
    // Select and animate ALL matching elements
    animatedElementSelectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      elements.forEach((el, index) => {
        // Skip if already initialized
       if (el.hasAttribute('data-animated')) return;
        
        // Mark as animated
        el.setAttribute('data-animated', 'true');
        
        // Add stagger delay based on parent context
        const staggerDelay = index * 80; // 80ms between siblings
        
        // Set initial state
        el.style.opacity = '0';
        el.style.transform = getInitialTransform(el);
        el.style.transition= `
          opacity 0.7s cubic-bezier(0.4, 0, 0.2, 1),
          transform 0.7s cubic-bezier(0.4, 0, 0.2, 1)
        `;
        el.style.transitionDelay = `${staggerDelay}ms`;
        el.style.willChange = 'opacity, transform';
        
        // Start observing
        universalAnimationObserver.observe(el);
      });
    });
    
    // Force another reflow
    setTimeout(() => {
     document.body.offsetHeight;
    }, 50);
  }
  
  // ============================================
  // ENHANCED 3D EFFECTS
  // ============================================
  
  // Parallax scrolling for images
  function initParallaxEffects() {
    let ticking = false;
    
    window.addEventListener('scroll', function() {
     if (!ticking) {
        window.requestAnimationFrame(function() {
          const scrolled = window.pageYOffset;
          
          // Hero image parallax
          const heroImage = document.querySelector('.hero-image');
         if (heroImage) {
            const rect = heroImage.getBoundingClientRect();
           if (rect.top < window.innerHeight && rect.bottom > 0) {
              const parallaxSpeed = 0.3;
              heroImage.style.transform = `translateY(${scrolled * parallaxSpeed}px) rotate(2deg)`;
            }
          }
          
          // Background parallax for sections
         document.querySelectorAll('section').forEach((section, index) => {
            const sectionRect = section.getBoundingClientRect();
           if (sectionRect.top < window.innerHeight && sectionRect.bottom > 0) {
              const speed = 0.1 + (index * 0.05);
              section.style.backgroundPositionY = `${scrolled * speed}px`;
            }
          });
          
          ticking = false;
        });
        ticking = true;
      }
    });
  }
  
  // Mouse-based 3D tilt effect on cards
  function init3DTiltEffect() {
   document.querySelectorAll('.innovation-feature, .impact-card, .problem-item, .vision-target').forEach(card => {
      card.addEventListener('mousemove', function(e) {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
        card.style.boxShadow = `
          ${-rotateY * 2}px ${rotateX * 2}px 20px rgba(0,0,0,0.15),
          0 4px 24px -4px hsl(var(--primary) / 0.12)
        `;
      });
      
      card.addEventListener('mouseleave', function() {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        card.style.boxShadow = '0 4px 24px -4px hsl(var(--primary) / 0.12)';
      });
    });
  }
  
  // ============================================
  // MOBILE NAVIGATION
  // ============================================
  
  const navbarToggle = document.querySelector('.navbar-toggle');
  const navbarMobile = document.querySelector('.navbar-mobile');
  
  if (navbarToggle && navbarMobile) {
    navbarToggle.addEventListener('click', function() {
      navbarMobile.classList.toggle('open');
      const isOpen = navbarMobile.classList.contains('open');
      navbarToggle.setAttribute('aria-expanded', isOpen);
    });
    
    const mobileLinks = document.querySelectorAll('.navbar-mobile.navbar-link');
    mobileLinks.forEach(link => {
      link.addEventListener('click', function() {
        navbarMobile.classList.remove('open');
      });
    });
  }
  
  // ============================================
  // SMOOTH SCROLL
  // ============================================
  
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
     if (href !== '#' && href.length > 1) {
        e.preventDefault();
        const target = document.querySelector(href);
       if (target) {
          const offsetTop = target.offsetTop -80;
          window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
          });
        }
      }
    });
  });
  
  // ============================================
  // INITIALIZATION
  // ============================================
  
  // Apply 3D perspective
  apply3DPerspective();
  
  // Initialize all animations
  initializeUniversalAnimations();
  
  // Add parallax effects (optional - can be removed if performance is concern)
  initParallaxEffects();
  
  // Add 3D tilt on hover (desktop only)
  if (window.matchMedia('(hover: hover)').matches) {
   init3DTiltEffect();
  }
});
